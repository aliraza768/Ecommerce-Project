const styles = {
   producttitle : "text-[25px] font-[600] font-Robotto text-[#333]",
   normalFlex : "flex items-center",
   heading :"text-[27px] text-center md:text-start font-[400px] font-Roboto pb-[20px]",
   Secction : "w-11/12 mx-auto",
   button : "w-[150px] bg-black h-[50px] my-3 flex items-center justify-center cursor-pointer rounded-xl",
   activestatus : "w-[10px] h-[10px] rounded-full absolute top-2 right-1 bg-[#40d132]",
   input : "w-[56] border p-3 rounded-[5px] ",
   cart_buttton_text : "text-[#fff] text-[16px] font-[600]",
   active_indicator : "absolute bottom-[-27%] left-0 h-[3px] w-full bg-[crimson]"
}

export default styles