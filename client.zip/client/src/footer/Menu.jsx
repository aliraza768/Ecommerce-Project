export const Products = [
    {name:"Drag And Drop", link:'#'},
    {name:"Visual Studio X", link:'#'},
    {name:"Easy Content", link:'#'},
   
]
export const Resourses = [
    {name:"Industrial And Tools", link:'#'},
    {name:"Use Case ", link:'#'},
    {name:"Blog ", link:'#'},
    {name:"Online Event", link:'#'},
    {name:"Noursted exerecration", link:'#'},
]
export const icons = [
    { name :"logo facebook" , link:"#"},
    { name :"logo twitter" , link:"#"},
    { name :"logo github" , link:"#"},
    { name :"logo instagarm" , link:"#"},
    { name :"logo linkrdin" , link:"#"},
]

export const Company = [
    {name:"Diveresty And Concluson", link:'#'},
    {name:"About Us ", link:'#'},
    {name:"Customer Stories", link:'#'},
    {name:"Press", link:'#'},
    {name:"Online Communication", link:'#'},
]

export const Support = [
    {name:"Documentation", link:'#'},
    {name:"Tutorials And Guids", link:'#'},
    {name:"Webniers", link:'#'},
    {name:"Open Source", link:'#'},
   
]