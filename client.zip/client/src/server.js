
export const server = " http://localhost:9000/api/v2"


