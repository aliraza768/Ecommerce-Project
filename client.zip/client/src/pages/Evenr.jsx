import React from 'react'
import styles from '../styles/styles'

const Evenrt = () => {
  return (
    <div className='w-full block bg-white rounded-lg lg:flex p-2' >
     <div className='w-full lg:w[50%] m-auto ml-10' >
        <img  src='https://res.cloudinary.com/dseka2tse/image/upload/v1716635394/computer-cases-housings-gaming-computer-laptop-desktop-computers-personal-computer-play-computer-games-63dc6f7b2a7b978d08f1cfb08be9f996_ul1m42.png' alt=''
        className=''
        />
     </div>
     <div className='w-full lg:[w-50%] flex flex-col justify-center mt-2' >
       <h2 className={`${styles.producttitle}`} >Computer Accessories Complete set of Computer</h2>
       <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nihil aspernatur illum vitae quis necessitatibus quo rem adipisci vero error. Incidunt eum deserunt necessitatibus voluptate itaque consequuntur quae quod dolorum quas.
       Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nihil aspernatur illum vitae quis necessitatibus quo rem adipisci vero error. Incidunt eum deserunt necessitatibus voluptate itaque consequuntur quae quod dolorum quas.
       </p>
     </div>
    </div>
  )
}

export default Evenrt
