import React from 'react'

const Bestselling = () => {
  return (
    <div>
        Ali Raza
    </div>
  )
}

export default Bestselling