export const navitems = [
    {
        title:"Home",
        url:"/",
    },
    {
        title:"Best Selling",
        url:"/best-selling",
    },
    {
        title:"Product",
        url:"/products",
    },
    {
        title:"Event",
        url:"/events",
    },
    {
        title:"Faq",
        url:"/faq",
    },
    
]