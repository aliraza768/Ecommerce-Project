export const catagoriesdata = [
 {
    id:1,
    title : "Computer And Laptop",
    subtitle : ""
 }, 
 {
    id:1,
    title : "Computer And Laptop",
    subtitle : ""
 }, 
 {
    id:1,
    title : "Computer And Laptop",
    subtitle : ""
 }, 
 {
    id:1,
    title : "Computer And Laptop",
    subtitle : ""
 }, 
 {
    id:1,
    title : "Computer And Laptop",
    subtitle : ""
 }, 
 {
    id:1,
    title : "Computer And Laptop",
    subtitle : ""
 }, 
 {
    id:1,
    title : "Computer And Laptop",
    subtitle : ""
 },   
]