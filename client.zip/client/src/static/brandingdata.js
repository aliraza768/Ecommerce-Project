export const brandingdata = [
  {
    id: 1,
    title: "Free Shipping",
    Description : "Famous Product"
    
  },
  {
    id: 2,
    title: "Daily Surprice Offer",
    Description : "Famous Product"
    
  },
  {
    id: 3,
    title: "AFFortAble Price", 
    Description : "Famous Product"
  },
  {
    id: 4,
    title: "Secure Payment",
    Description : "Famous Product"
  },
];
