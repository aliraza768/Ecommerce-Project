const SES = require("aws-sdk/clients/ses");

exports.DATABASE_LOCAL = "mongodb://127.0.0.1/apnaghar";
exports.AWS_ACCESS_KEY_ID = "AKIAU6GDUKWSWCMKL6NB";
exports.AWS_SECRET_ACCESS_KEY = "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";
exports.EMAIL_FROM = "aliraza564257@gmail.com"
exports.REPLY_TO = "ranaafaqranaafaq68@gmail.com";
exports.AWS_REGION = "eu-north-1"
exports.AWS_API_VERSION = "2010-12-10";
const awsConfig = {
  accessKeyId: exports.AWS_ACCESS_KEY_ID,
  secretAccessKey: exports.AWS_SECRET_ACCESS_KEY,
  region: exports.AWS_REGION,
  apiVersion: exports.AWS_API_VERSION,
};
exports.AWSSES = new SES(awsConfig);
exports.JWT_SECRET = "JSHLWKERJHWLEHJSFSJSFJWLEHALKSDHF34J34HJKL3JK003JHS";
exports.CLIENT_URL = "http://localhost:3000";

module.exports = exports;